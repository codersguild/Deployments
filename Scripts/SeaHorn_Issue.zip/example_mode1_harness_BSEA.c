#include "../../../output/IntegerOverflowMultiTxMultiFuncFeasible_functions.h"
#include<stdio.h>
#include<string.h>
#include<stdint.h>
#include<assert.h>
#include "../../../seahorn.h"
#include "../../../config.h"
#include "../../../impl.h"
 extern int nd();

int main()
{
	int bound = TRANSACTION_BOUND;
	init();

	while(bound--)
	{
		int c;
		c = nd();
		assume(c>=0 && c<2);
		init_counter();
		switch(c)
		{
		case 0:
		{

			slot_type arg0;
			arg0 = nd();
			assume(arg0>9 && arg0<14);

			slot_type arg1;
			arg1 = nd();
			assume(arg1>= INT_LOWER_BOUND && arg1<= INT_UPPER_BOUND);

			IntegerOverflowMultiTxMultiFuncFeasible_init_0xe1c7392a(arg0,arg1);
			break;
		}
		case 1:
		{

			slot_type arg0;
			arg0 = nd();
			assume(arg0>9 && arg0<14);

			slot_type arg1;
			arg1 = nd();
			assume(arg1>= INT_LOWER_BOUND && arg1<= INT_UPPER_BOUND);

			slot_type arg2;
			arg2 = nd();
			assume(arg2>= INT_LOWER_BOUND && arg2<= INT_UPPER_BOUND);

			IntegerOverflowMultiTxMultiFuncFeasible_run_0xa444f5e9(arg0,arg1,arg2);
			break;
		}

		}

	}

}
